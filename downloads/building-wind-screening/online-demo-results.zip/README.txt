Building Wind Screening — web adapter 1.0.0

Direct input: reference wind-speed scenario (m/s), incoming direction, rectangular footprints in meters, clockwise rotation, height and floors, optional rectangular open areas. No map/image is required. Heights are explicit inputs; no floor-height inference is performed.

The server runs a headless mathematical snapshot of the author-owned desktop prototype. Dataclasses, constants and calculation functions retain their original AST. Source and snapshot hashes are recorded in report.json. The source desktop program and existing projects are unchanged.

q_ref = 0.5 * rho * V^2 / 1000 kPa, rho = 1.25 kg/m3. The prototype then uses a clipped logarithmic height/roughness and turbulence expression for qp(z), with empirical facade, corner, height-band, shielding, shape, open-area and nearby-building factors. All are model assumptions; the included JRC wind-action background does not establish conformity to a design standard.

Read buildings.csv for peak exposure ranking, facades.csv for four facades × four height bands, and directions.csv for a fixed 15-degree direction scan. plan.svg shows entered geometry, facades.svg compares band maxima, directions.svg shows sensitivity. Colors indicate relative modeled exposure, not a calibrated safety threshold. input.json and report.json retain the inputs and numerical detail; original Chinese core labels are preserved.

Only the submitting approved account can view/download these files. Server copies expire after 72 hours.

Limitations:
- Heuristic wind-pressure exposure screening only: not CFD, wind-tunnel validation, code compliance, component resistance or breakage probability.
- Reference V is an input parameter of the original model. Its averaging time and terrain normalization are not calibrated to a site wind record; do not insert an observed gust or a design-code speed without a justified mapping.
- Values are nonnegative pressure magnitudes, not signed pressures. The original algorithm adds absolute external/internal coefficients and empirical multipliers.
- Only entered rectangles/open areas contribute to context. Missing neighbors, topography, true openings, shape details and resistance are not inferred.
- Four height bands sample representative heights and empirical edge factors. They are not a per-floor or local corner pressure solution.
