TPA web workflow — adapter 1.0.0

Primary input: Gaussian fchk and log from the same completed, all-electron, closed-shell singlet TD calculation. IOp(9/40=4) and 2–40 singlet excited states are required. Atom order, coordinates/axes/origin, state energies and available SCF energies are checked. The server does not run Gaussian or formchk.

The pinned non-GUI Multiwfn 3.8 development build executes only the fixed 18 → 5 → explicit log → 2 export sequence, with two threads. Its exact binary hash and license are included/recorded. Excited diagonal elements in this export are electronic. Ground total dipole is converted to electronic by subtracting the nuclear vector computed from fchk Nuclear charges × Cartesian coordinates (bohr). All-electron charge/electron consistency is checked. The resulting diagonal vectors share one definition before applying delta_mu_i = mu_ii - saved_mu_00; the ground reference is copied before any diagonal is changed. Nuclear contribution being near zero is reported numerically, not assumed. Text mode instead records the user-supplied definitions/vector.

The original audited Python SOS core is used without changing its constants, damping, equations or grid. It constructs gamma, averages isotropically and uses the imaginary response to calculate the reported cross section. Denominator damping is 0.05 eV. The fix prevents reference overwrite; it is not a complete physical validation. No equality with legacy MATLAB results is certified.

spectrum.csv and spectrum.svg use incident photon wavelength lambda2_nm. lambda_half_nm is the equivalent one-photon wavelength. Preserve negative response values and inspect all warnings. dipole_reference.csv exposes raw/common-basis/difference vectors. report.json records hashes, input checks, state count, definitions and limits. Download within 72 hours; results are accessible only to the submitting approved account.

Theory references:
Terenziani et al., Advanced Materials 20, 4641–4678 (2008), DOI 10.1002/adma.200800402.
Orr and Ward, Molecular Physics 20, 513–526 (1971), DOI 10.1080/00268977100100481.
Göppert-Mayer, Annalen der Physik 401, 273–294 (1931), DOI 10.1002/andp.19314010303.
Multiwfn: Lu and Chen, J. Comput. Chem. 33, 580–592 (2012), DOI 10.1002/jcc.22885; Lu, J. Chem. Phys. 161, 082503 (2024), DOI 10.1063/5.0216272; cite both Multiwfn papers in the main text as requested by the pinned build, and cite your Gaussian/method/basis as appropriate.

Warnings:
- Dipole definitions and nuclear vector were explicitly supplied by the user; they cannot be independently verified from a text export alone.
- The reference-copy fix prevents mu00 being overwritten before subtraction; it does not by itself validate SOS prefactors, state convergence or the absolute cross section.
- All supplied excited states are used (2–40). Denominator damping is fixed at 0.05 eV; no state search, quantum calculation, geometry optimization or ML prediction is run.
- The original Python constants, frequency grid and SOS equations are retained, including the legacy 0.528 Å atomic-dipole conversion. Python/MATLAB numerical equivalence is not claimed.
- Fitted damping and a finite set of states do not constitute experimental accuracy. Permanent and transition dipoles must share units, axes and electronic/total conventions.
