Surfacia descriptor-table web analysis, adapter 1.0.0

This run calls the published Surfacia 4.0.0 XGB_Fit training routine. The web adapter uses fixed all-feature XGBoost regression, 350 trees, depth 8, learning rate 0.03, CPU 2 threads. Full parameters, source hash, input hash and package versions are in report.json.

Validation differs from the desktop CLI repeated random-split workflow: identical descriptor vectors stay together; 20% of descriptor groups are held out with seed 42. Five GroupKFold models produce exactly one out-of-fold prediction for every modeling row. A final model fitted on the full modeling pool predicts the untouched held-out rows. There is no optimization, feature selection or early stopping; eval_set in XGB_Fit does not change these fixed settings. No imputation or scaling is applied.

predictions.csv records split membership and OOF folds. Inspect MAE, RMSE, R2 and the training-mean baseline together. Metrics from very small or constant test sets are unstable; undefined R2 is null.

shap_values.csv contains signed TreeSHAP contributions and original descriptor values for held-out rows. expected_value + sum(SHAP_*) reproduces the prediction within numerical tolerance. feature_importance.csv ranks held-out mean(abs(SHAP)); sign and magnitude answer different questions. Correlated descriptors can redistribute attribution. SHAP is not causal evidence or proof of a chemical mechanism. Optional smiles are ignored; no molecular surfaces or quantum calculations are generated.

parity.png, shap_importance.png and shap_dependence.png are exploratory plots. model.json is the final native XGBoost model; use the recorded feature order and versions for reproduction. The service never accepts uploaded models.

Only your account can download this archive. Server files expire after 72 hours: download your results promptly.

References: Surfacia https://pypi.org/project/surfacia/4.0.0/ ; TreeSHAP https://shap.readthedocs.io/en/latest/generated/shap.TreeExplainer.html ; archived research preprint https://doi.org/10.26434/chemrxiv.15007949/v1 (predates the current scope; not this web validation protocol).

Warnings:
- Random grouped validation is not a scaffold, chronological or external-laboratory test.
- SHAP attributes the fitted prediction; correlation, causality and chemical mechanisms require independent evidence.
- One fixed split and model are an exploratory analysis, not the frozen manuscript benchmark.
- Small dataset: held-out metrics and feature ranks can be unstable.
